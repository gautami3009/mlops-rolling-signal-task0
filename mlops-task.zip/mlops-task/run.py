#!/usr/bin/env python3
"""
run.py - Minimal MLOps-style batch job.

Loads OHLCV data, computes a rolling mean on `close`, derives a binary
trading signal, and writes structured metrics (metrics.json) plus
detailed logs (run.log).

Usage:
    python run.py --input data.csv --config config.yaml --output metrics.json --log-file run.log
"""

import argparse
import json
import logging
import os
import sys
import time

import numpy as np
import pandas as pd
import yaml

VERSION_FALLBACK = "v1"


def parse_args():
    parser = argparse.ArgumentParser(description="Rolling-mean signal batch job.")
    parser.add_argument("--input", required=True, help="Path to input CSV (OHLCV data).")
    parser.add_argument("--config", required=True, help="Path to YAML config file.")
    parser.add_argument("--output", required=True, help="Path to write metrics JSON.")
    parser.add_argument("--log-file", required=True, help="Path to write log file.")
    return parser.parse_args()


def setup_logging(log_file_path):
    logger = logging.getLogger("mlops_task")
    logger.setLevel(logging.INFO)
    logger.handlers = []  # avoid duplicate handlers if re-invoked

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    )

    file_handler = logging.FileHandler(log_file_path, mode="w")
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)

    return logger


def write_metrics(output_path, payload):
    with open(output_path, "w") as f:
        json.dump(payload, f, indent=2)


def load_and_validate_config(config_path, logger):
    if not os.path.isfile(config_path):
        raise FileNotFoundError(f"Config file not found: {config_path}")

    with open(config_path, "r") as f:
        try:
            config = yaml.safe_load(f)
        except yaml.YAMLError as e:
            raise ValueError(f"Invalid YAML in config file: {e}")

    if not isinstance(config, dict):
        raise ValueError("Invalid config structure: expected a YAML mapping (key: value).")

    required_fields = ["seed", "window", "version"]
    missing = [field for field in required_fields if field not in config]
    if missing:
        raise ValueError(f"Config missing required field(s): {', '.join(missing)}")

    if not isinstance(config["seed"], int):
        raise ValueError("Config field 'seed' must be an integer.")
    if not isinstance(config["window"], int) or config["window"] < 1:
        raise ValueError("Config field 'window' must be a positive integer.")
    if not isinstance(config["version"], str):
        raise ValueError("Config field 'version' must be a string.")

    logger.info(
        "Config loaded + validated (seed=%s, window=%s, version=%s)",
        config["seed"], config["window"], config["version"],
    )
    return config


def load_and_validate_dataset(input_path, logger):
    if not os.path.isfile(input_path):
        raise FileNotFoundError(f"Input file not found: {input_path}")

    if os.path.getsize(input_path) == 0:
        raise ValueError("Input file is empty.")

    try:
        df = pd.read_csv(input_path)
    except pd.errors.EmptyDataError:
        raise ValueError("Input file is empty or contains no columns.")
    except pd.errors.ParserError as e:
        raise ValueError(f"Invalid CSV format: {e}")

    if df.empty:
        raise ValueError("Input CSV contains no rows.")

    if "close" not in df.columns:
        raise ValueError("Required column 'close' not found in input CSV.")

    if not pd.api.types.is_numeric_dtype(df["close"]):
        df["close"] = pd.to_numeric(df["close"], errors="coerce")
        if df["close"].isna().all():
            raise ValueError("Column 'close' contains no valid numeric data.")

    logger.info("Rows loaded: %d", len(df))
    return df


def compute_rolling_signal(df, window, logger):
    logger.info("Processing step: computing rolling mean (window=%d) on 'close'.", window)
    df = df.copy()
    df["rolling_mean"] = df["close"].rolling(window=window, min_periods=window).mean()

    logger.info("Processing step: generating binary signal (close > rolling_mean).")
    # Rows where rolling_mean is NaN (the first window-1 rows) are excluded
    # from signal computation to keep the metric well-defined and deterministic.
    valid = df["rolling_mean"].notna()
    df["signal"] = np.where(valid & (df["close"] > df["rolling_mean"]), 1, 0)
    df.loc[~valid, "signal"] = np.nan

    return df


def main():
    args = parse_args()
    logger = setup_logging(args.log_file)
    start_time = time.time()
    logger.info("Job start.")

    version = VERSION_FALLBACK
    try:
        config = load_and_validate_config(args.config, logger)
        version = config["version"]

        np.random.seed(config["seed"])
        logger.info("Random seed set to %s for reproducibility.", config["seed"])

        df = load_and_validate_dataset(args.input, logger)
        df = compute_rolling_signal(df, config["window"], logger)

        valid_signals = df["signal"].dropna()
        rows_processed = len(df)
        signal_rate = float(valid_signals.mean()) if len(valid_signals) > 0 else 0.0
        latency_ms = int(round((time.time() - start_time) * 1000))

        metrics = {
            "version": version,
            "rows_processed": rows_processed,
            "metric": "signal_rate",
            "value": round(signal_rate, 4),
            "latency_ms": latency_ms,
            "seed": config["seed"],
            "status": "success",
        }

        logger.info(
            "Metrics summary: rows_processed=%d, signal_rate=%.4f, latency_ms=%d",
            rows_processed, signal_rate, latency_ms,
        )

        write_metrics(args.output, metrics)
        logger.info("Job end. status=success")
        print(json.dumps(metrics, indent=2))
        sys.exit(0)

    except Exception as e:
        logger.exception("Job failed with an exception: %s", e)
        error_metrics = {
            "version": version,
            "status": "error",
            "error_message": str(e),
        }
        try:
            write_metrics(args.output, error_metrics)
        except Exception as write_err:
            logger.exception("Failed to write error metrics file: %s", write_err)

        logger.info("Job end. status=error")
        print(json.dumps(error_metrics, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
